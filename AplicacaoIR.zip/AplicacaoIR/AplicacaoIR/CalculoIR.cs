﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicacaoIR
{
     class CalculoIR
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Sistema de Cálculo de Imposto de Renda sobre Produtos Financeiros - SCIRPF");
            Console.WriteLine("Insira o valor aplicado: ");
            double valor = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Valor Investido:R$" + valor);


            if (valor < 0 || valor == 0)
            {
                Console.WriteLine("No momento você não possui nenhuma aplicação.Operação Encerrada.");

            }

            if (valor > 0)

            {
                Console.WriteLine("Qual a data de aplicação?:");

                DateTime dataAplicacao = DateTime.Parse(Console.ReadLine());

                Console.WriteLine("Data de Aplicação:" + dataAplicacao);


                Console.WriteLine("Qual a data de resgate?:");
                DateTime dataResgate = DateTime.Parse(Console.ReadLine());

                Console.WriteLine("Data de Resgate:" + dataResgate);

                if (dataAplicacao > dataResgate)
                {
                    Console.WriteLine("Favor inserir um período válido");
                }
                if (dataAplicacao<dataResgate) {
                    TimeSpan tempoAnos = dataResgate - dataAplicacao;

                    Console.WriteLine("Duração de aplicação?:" + tempoAnos.Days + "Dias");
                    //int tempoAnos = int.Parse(Console.ReadLine());

                    //     Console.WriteLine("Anos Aplicados: " + tempoAnos + "Anos");


                    if (tempoAnos.Days <= 365 || tempoAnos.Days == 365)
                    {
                        double imposto = (0.225 * valor);

                        Console.WriteLine("Você deverá pagar: " + imposto + " reais sobre a aplicação de " + tempoAnos.Days + " Dias");
                    }
                    if (tempoAnos.Days > 365 || tempoAnos.Days == 730)
                    {
                        double imposto = (0.185 * valor);


                        Console.WriteLine("Você deverá pagar: " + imposto + " reais sobre a aplicação de " + tempoAnos.Days + " Dias");
                    }
                    if (tempoAnos.Days > 730)
                    {
                        double imposto = (0.15 * valor);
                        Console.WriteLine("Você deverá pagar: " + imposto + " reais sobre a aplicação de " + tempoAnos.Days + " Dias");
                    }

                }
            }
        }

    }
}

