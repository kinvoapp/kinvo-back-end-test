﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Aliquota.Domain.Test
{
  public  class CalculoIRTest
    {
        [Fact]
        public void Receber_Valor_RetornaValor()
        {
            // Arrange  
           

           
            //Assert  
            
        }
        public void Receber_Data_RetorndaData()
        {



        }
        public void Retornar_Aplicacao()
        {

        }


    }
}
